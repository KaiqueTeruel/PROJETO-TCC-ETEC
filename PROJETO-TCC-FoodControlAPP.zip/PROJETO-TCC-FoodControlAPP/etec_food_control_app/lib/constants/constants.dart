import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

// CONSTANTES DE CORES
const kBackgroundColor = Color(0xFFFFFFFF);
const kActiveIconColor = Color(0xFFF9A826);
const kTextColor = Color(0xFFE6E6E6);
const kBlueLightColor = Color(0xFF0095FF);
const kBlueColor = Color(0xFF007CD4);
const kShadowColor = Color(0xFFE6E6E6);