import 'package:flutter/material.dart';
import 'package:etec_food_control_app/constants/constants.dart';

class PedidoAlmoco extends StatelessWidget {
  const PedidoAlmoco({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // BASE DO FUNDO DO APLICATIVO
      backgroundColor: kBlueLightColor,
      appBar: AppBar(
        elevation: 1.0,
        backgroundColor: Theme.of(context).colorScheme.secondary,
        title: Text(
          "EtecFoodControl",
          style: TextStyle(
            fontFamily: "Cairo",
            fontSize: 24,
          ),
        ),
        centerTitle: true,
      ),
      body: Container(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: double.infinity,
          decoration: BoxDecoration(
            color: kBackgroundColor,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(30),
              topRight: Radius.circular(30),
            ),
          ),
          child: ListView(
            padding: EdgeInsets.only(left: 20, top: 20),
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 30, left: 60),
                child: Text(
                  "Seja Bem-Vindo a Tela de Pedido", textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: "Cairo",
                    fontSize: 18,
                    color: Colors.black87,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),

              // CONTAINER CENTRAL DOS BOTOES
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 30,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      "Complete as Informações Abaixo:", textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: "Cairo",
                        fontSize: 16,
                        color: Colors.black,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        top: 20,
                      ),
                      child: Container(
                        height: 450,
                        child: GridView.count(
                          crossAxisCount: 2,
                          crossAxisSpacing: 10,
                          mainAxisSpacing: 10,
                          childAspectRatio: 1.1,
                          children: [],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
