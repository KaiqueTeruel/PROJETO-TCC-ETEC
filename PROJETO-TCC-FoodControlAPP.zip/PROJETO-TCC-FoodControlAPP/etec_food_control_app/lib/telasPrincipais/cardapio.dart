import 'package:etec_food_control_app/telasPrincipais/avaliar.dart';
import 'package:etec_food_control_app/telasPrincipais/cardapio.dart';
import 'package:etec_food_control_app/telasPrincipais/solicitar.dart';
import 'package:etec_food_control_app/telasPrincipais/suporte.dart';
import 'package:flutter/material.dart';
import 'package:etec_food_control_app/constants/constants.dart';

class CardapioPage extends StatelessWidget {
  const CardapioPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // BASE DO FUNDO DO APLICATIVO
      backgroundColor: kBlueLightColor,
      appBar: AppBar(
        elevation: 1.0,
        backgroundColor: Theme.of(context).colorScheme.secondary,
        title: Text(
          "EtecFoodControl",
          style: TextStyle(
            fontFamily: "Cairo",
            fontSize: 24,
          ),
        ),
        centerTitle: true,
      ),
      body: Container(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: double.infinity,
          decoration: BoxDecoration(
            color: kBackgroundColor,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(30),
              topRight: Radius.circular(30),
            ),
          ),
          child: ListView(
            padding: EdgeInsets.only(left: 20, top: 20),
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 30, left: 0),
                child: Text(
                  "Bem-Vindo a Tela de Cardápio",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: "Cairo",
                    fontSize: 18,
                    color: Colors.black87,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),

              // CONTAINER CENTRAL DOS BOTOES
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 30,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      "Faça o Download Abaixo:",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: "Cairo",
                        fontSize: 16,
                        color: Colors.black,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        top: 20,
                      ),
                      child: Container(
                        height: 292,
                        child: GridView.count(
                          crossAxisCount: 1,
                          crossAxisSpacing: 5,
                          mainAxisSpacing: 10,
                          childAspectRatio: 6.1,
                          children: [
                            MaterialButton(
                              child: Text(
                                "FAÇA O DOWNLOAD AQUI!",
                                style: TextStyle(
                                    fontSize: 16,
                                    fontFamily: "Cairo",
                                    fontWeight: FontWeight.bold),
                              ),
                              textColor: kTextColor,
                              minWidth: 10,
                              height: 10,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15)),
                              elevation: 5,
                              onPressed: () {},
                              color: Color(0xFF0095FF), 
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.only(top: 0),
                height: 240,
                child: Image.asset("assets/images/CardapioF.png"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
