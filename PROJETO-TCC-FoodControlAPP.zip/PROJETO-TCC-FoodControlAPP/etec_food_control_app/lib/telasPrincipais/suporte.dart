import 'package:flutter/material.dart';
import 'package:etec_food_control_app/constants/constants.dart';
import 'package:url_launcher/url_launcher.dart';

class SuportePage extends StatelessWidget {
  const SuportePage({Key? key}) : super(key: key);
  Future<void> _launchLink(String url) async {
    if (await canLaunch(url)) {
      await launch(url, forceWebView: false, forceSafariVC: false);
    } else {
      print('Não pode executar o Link $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // BASE DO FUNDO DO APLICATIVO
      backgroundColor: kBlueLightColor,
      appBar: AppBar(
        elevation: 1.0,
        backgroundColor: Theme.of(context).colorScheme.secondary,
        title: Text(
          "EtecFoodControl",
          style: TextStyle(
            fontFamily: "Cairo",
            fontSize: 24,
          ),
        ),
        centerTitle: true,
      ),
      body: Container(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: double.infinity,
          decoration: BoxDecoration(
            color: kBackgroundColor,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(30),
              topRight: Radius.circular(30),
            ),
          ),
          child: ListView(
            padding: EdgeInsets.only(left: 20, top: 20),
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 30, left: 8),
                child: Text(
                  "Seja Bem-Vindo a Tela de Suporte",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: "Cairo",
                    fontSize: 18,
                    color: Colors.black87,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),

              // CONTAINER CENTRAL DOS BOTOES
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 30,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      "Escolha Uma Opção para Receber Seu Suporte:",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: "Cairo",
                        fontSize: 16,
                        color: Colors.black,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 30, left: 0),
                      child: Container(
                        alignment: Alignment.center,
                        height: 80,
                        child: GridView.count(
                          crossAxisCount: 1,
                          crossAxisSpacing: 5,
                          mainAxisSpacing: 10,
                          childAspectRatio: 6.1,
                          children: [
                            MaterialButton(
                              child: Text(
                                "ENVIE SEU E-MAIL AQUI!",
                                style: TextStyle(
                                    fontSize: 16,
                                    fontFamily: "Cairo",
                                    fontWeight: FontWeight.bold),
                              ),
                              textColor: kTextColor,
                              minWidth: 10,
                              height: 10,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15)),
                              elevation: 5,
                              onPressed: () =>
                                  _launchLink('mailto:e166dir@cps.sp.gov.br'),
                              color: Color(0xFF0095FF),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.only(top: 0),
                height: 240,
                child: Image.asset("assets/images/SuporteF.png"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
