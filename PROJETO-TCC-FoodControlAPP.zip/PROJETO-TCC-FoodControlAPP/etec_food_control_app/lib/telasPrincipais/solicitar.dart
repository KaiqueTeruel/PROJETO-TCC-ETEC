import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:etec_food_control_app/telasPrincipais/homePage.dart';
import 'package:flutter/material.dart';
import 'package:etec_food_control_app/constants/constants.dart';
import 'package:flutter/services.dart';

class SolicitarPage extends StatelessWidget {
  TextEditingController nome = TextEditingController();
  TextEditingController pedido = TextEditingController();
  TextEditingController rm = TextEditingController();
  TextEditingController turma = TextEditingController();

  CollectionReference ref = FirebaseFirestore.instance.collection("Alunos");

  final List<String> _items = [
    '1º Médio',
    '2º Médio',
    '3º Médio',
  ];
  final _dropDownValue = '1º Médio';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // BASE DO FUNDO DO APLICATIVO
      backgroundColor: kBlueLightColor,
      appBar: AppBar(
        elevation: 1.0,
        backgroundColor: Theme.of(context).colorScheme.secondary,
        title: Text(
          "EtecFoodControl",
          style: TextStyle(
            fontFamily: "Cairo",
            fontSize: 24,
          ),
        ),
        centerTitle: true,
      ),
      body: Container(
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration(
            color: kBackgroundColor,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(30),
              topRight: Radius.circular(30),
            ),
          ),
          child: ListView(
            padding: EdgeInsets.only(left: 20, top: 20),
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 30, left: 0),
                child: Text(
                  "Seja Bem-Vindo a Tela de Solicitação",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: "Cairo",
                    fontSize: 18,
                    color: Colors.black87,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),

              // CONTAINER CENTRAL DOS BOTOES
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 30,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      "Complete as Informações:",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: "Cairo",
                        fontSize: 16,
                        color: Colors.black,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        top: 20,
                      ),
                      child: Container(
                        height: 40,
                        width: 200,
                        child: GridView.count(
                          crossAxisCount: 1,
                          crossAxisSpacing: 1,
                          mainAxisSpacing: 1,
                          childAspectRatio: 1.4,
                        ),
                      ),
                    ),
                    SizedBox(
                      child: Container(
                        child: TextFormField(
                          maxLength: 50,
                          textAlign: TextAlign.start,
                          inputFormatters: [
                            LengthLimitingTextInputFormatter(50),
                          ],
                          controller: nome,
                          expands: false,
                          maxLines: null,
                          decoration: InputDecoration(
                            labelText: "Nome",
                            labelStyle: TextStyle(fontFamily: "Cairo"),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15)),
                          ),
                        ),
                      ),
                    ),
                    Padding(padding: EdgeInsets.only(top: 5)),
                    SizedBox(
                      child: Container(
                        child: TextFormField(
                          maxLength: 5,
                          textAlign: TextAlign.start,
                          inputFormatters: [
                            LengthLimitingTextInputFormatter(5),
                          ],
                          controller: rm,
                          expands: false,
                          maxLines: null,
                          decoration: InputDecoration(
                            labelText: "Rm",
                            labelStyle: TextStyle(fontFamily: "Cairo"),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15)),
                          ),
                        ),
                      ),
                    ),
                    Padding(padding: EdgeInsets.only(top: 5)),
                    SizedBox(
                      child: Container(
                        child: TextFormField(
                          maxLength: 10,
                          textAlign: TextAlign.start,
                          inputFormatters: [
                            LengthLimitingTextInputFormatter(10)
                          ],
                          controller: turma,
                          expands: false,
                          maxLines: null,
                          decoration: InputDecoration(
                            labelText: "Turma",
                            labelStyle: TextStyle(fontFamily: "Cairo"),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15)),
                          ),
                        ),
                      ),
                    ),
                    Padding(padding: EdgeInsets.only(top: 20)),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        MaterialButton(
                          textColor: kTextColor,
                          minWidth: 250,
                          height: 80,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15)),
                          elevation: 5,
                          color: Color(0xFF0095FF),
                          onPressed: () {
                            ref.add(
                              {
                                'Nome': nome.text,
                                'Pedido': pedido.text = 'Sim',
                                'RM': rm.text,
                                'Turma': turma.text,
                              },
                            ).whenComplete(() => Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(builder: (_) => HomePage())));
                          },
                          child: Text(
                            'SOLICITAR',
                            style: TextStyle(
                                fontFamily: "Cairo",
                                fontWeight: FontWeight.bold,
                                fontSize: 16),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.only(top: 0),
                height: 240,
                child: Image.asset("assets/images/SolicitarF.png"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
