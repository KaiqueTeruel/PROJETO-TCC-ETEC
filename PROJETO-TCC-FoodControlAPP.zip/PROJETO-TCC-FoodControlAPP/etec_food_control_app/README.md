# etec_food_control_app

## Integrantes:
**1.Kaique Pinheiro Teruel**<br>
**2.Kaique pimenta Cabral**<br>
**3.GUILHERME DE PAULA SILVA**<br>
**4.Vinicius de Sousa vieira**<br>
**5.Richard carvalho dos anjos**<br>

### Descrição

<p> Nosso projeto foi formulado com a necessidade de uma melhor gestão no controle de alimentos na Etec Jucelino Kubitscheck de Oliveira.
Através de uma analise com o Professor tivemos uma oportunidade de implantação do Projeto vigente.
O controle será feito através de um Aplicativo, onde os alunos realizaram seu cadastro através do e-mail e rm, com isso o aluno pode realizar o pedido da sua alimentação dentro do app. Outro opção disponivel dentro do Aplicativo e a Avaliação da refeição que será realizada pelo alunos e consultada pela Diretoria da Unidade por meio de um sugundo Aplicativo totalmente exclusivo da Direção da unidade. Também havera uma área com o Cardápio Mensal da unidade e uma ultima área de suporte para os alunos relatarem qualquer erro ou problema com o Aplicaivo.
O processo de criação foi feito através de etapas projeção, recolhimentos de dados, visual, funcionamento, testes, resolução de defeitos e conclusão.</p>
