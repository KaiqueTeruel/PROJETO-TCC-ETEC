package com.example.etec_food_control_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
